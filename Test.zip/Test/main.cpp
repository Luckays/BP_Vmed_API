#include <iostream>
#include <mutex>
#include <fstream>
#include <unistd.h>
#include <stdio.h>
const int NUM_SECONDS = 60;
std::mutex logMutex;
bool fileExists(std::string& fileName) {
    return static_cast<bool>(std::ifstream(fileName));
}
template <typename filename, typename T1, typename T2, typename T3,typename T4,typename T5,typename T6,typename T7>
bool writeCsvFile(filename &fileName, T1 column1, T2 column2, T3 column3,T4 column4,T5 column5,T6 column6,T7 column7) {
    std::lock_guard<std::mutex> csvLock(logMutex);
    std::fstream file;
    file.open (fileName, std::ios::out | std::ios::app);
    if (file) {
        file << " " << column1 << " ";
        file << " " << column2 << " ";
        file << " " << column3 << " ";
        file << " " << column4 << " ";
        file << " " << column5 << " ";
        file << " " << column6 << " ";
        file << " " << column7 << " ";
        file <<  std::endl;
        return true;
    } else {
        return false;
    }
}
int main() {
    int year{2020}, month{4},day{16},hour{15},minute{06},second{0},value{rand()%100};
    std::string csvFile = "../../WebstormProjects/realtimesql/slozka2/20200416.ALL";
    if(!fileExists(csvFile))
        int i;
    int count = 1;
    writeCsvFile(csvFile, year, month, day, hour, minute, second, value);
    while(true) {
        // delay for 10 seconds
        for (int i = 0; i < NUM_SECONDS; i++) { usleep(1000 *1000); }
        minute++;
        if(minute>59){
            hour++;
            minute = 0;
        };
        if(hour == 24){
            day++;
            hour =0;
        };
        if (day > 31){
            month++;
            day = 1;
        };
        if (month > 12){
            year++;
            month =1;
        };
        value = rand()%100;
        std::cout<<count<<std::endl;
        writeCsvFile(csvFile, year, month, day, hour, minute, second, value);
    }
    return 0;
}

